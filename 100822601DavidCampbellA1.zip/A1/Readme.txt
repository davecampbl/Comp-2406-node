Name: David Campbell
Stu#100822601


I was using Windows 7 for my project, I made the powerpoints using the mac version of Office 2008

to run Question 1: simply run node on 'Q1.js'
In the powerpoint I used a list of only 1 item because it greatly simplified the stack/heap example.
The actual code runs Quicksort and can be used on larger lists

to run Question 2: simply run node on 'Q2.js'

to run question 3: simply run node on 'Q3.js'
I had trouble thinking of a meaningful application for this question.

to run question 4: run node on 'Q4.js' then enter the URL http://localhost:3000/index.html
the files are linked there.
There seems to be a strange issue once in a while where the index page loads a different version, or a different page, it could be specific to my browser though.
most of the old files from Tutorial 2 are still on the server as well.
 