Student number 100822601
David Campbell

I did my work on a windows machine. To run the application from run node on www, in the bin directory.
I used Professor Nel's demo code as the starting point for this assignment, much of the code in app.js and www were left unchanged.
Everything seems to work after testing on my machine, I used Chrome and firefox to test multiple connections.
to access the page go to http://localhost:3000
I completed the first bonus question, there is an admin user who can create new users. new TAs are not given the old assignments however.
late dates will only update if the page is refreshed, so if you create an assignment that was due in the past it will require a refresh to change it to late status.
There are few error messages, the program just redirects you to the page you were on previously if there was an invalid input.
There are 6 hard coded users, and one hard coded assignment.
Users:
Username	Password	Privileges	Description
STU1		1UTS		STU		Student user
STU2		2UTS		STU		Studing user
TA1		1AT		TA		TA user
TA2		2AT		TA		TA user
PROF		FORP		PROF		Professor user
ADMIN		ADMIN		ADM		Admin user

The assignment is created with both a starting and ending date of when the program is first run.
